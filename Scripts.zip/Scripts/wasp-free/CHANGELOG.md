## [2.10.24](https://github.com/Torwent/wasp-free/compare/v2.10.23...v2.10.24) (2023-12-26)


### Bug Fixes

* all scripts updated their deprecated methods ([74707fd](https://github.com/Torwent/wasp-free/commit/74707fd468cfa435eb711087815cb806b177c9eb))



## [2.10.23](https://github.com/Torwent/wasp-free/compare/v2.10.22...v2.10.23) (2023-12-26)


### Bug Fixes

* read notes ([eae2c3c](https://github.com/Torwent/wasp-free/commit/eae2c3c6e5df24de2640459722f1cd38685bfbbc))



## [2.10.22](https://github.com/Torwent/wasp-free/compare/v2.10.21...v2.10.22) (2023-12-20)


### Bug Fixes

* same exact update wasp-premium had ([58f8dd8](https://github.com/Torwent/wasp-free/commit/58f8dd889833dc12cd5607afa30ecb47d4b34b22))



## [2.10.21](https://github.com/Torwent/wasp-free/compare/v2.10.20...v2.10.21) (2023-12-16)


### Bug Fixes

* **offerer:** shouldnt't crash every few hours anymore ([e522baa](https://github.com/Torwent/wasp-free/commit/e522baa828886cfb28dfa901bd795df946861bc5))



## [2.10.20](https://github.com/Torwent/wasp-free/compare/v2.10.19...v2.10.20) (2023-12-11)


### Bug Fixes

* **reld wrath runecrafter:** refactor ([eb45062](https://github.com/Torwent/wasp-free/commit/eb45062a02264386539c7829030e8a93f89b97d5))



